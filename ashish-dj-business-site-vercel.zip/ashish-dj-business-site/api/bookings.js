/**
 * Vercel serverless function: validates a booking enquiry and inserts it into Supabase.
 * Configure SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in Vercel Project Settings.
 * Never put the service-role key in browser-side JavaScript or commit it to Git.
 */
const jsonError = (res, status, message) =>
  res.status(status).setHeader("Cache-Control", "no-store").json({ error: message });

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return jsonError(res, 405, "Method not allowed.");
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceKey) {
    return jsonError(res, 503, "Booking database is not configured yet.");
  }

  let body = req.body;
  if (typeof body === "string") {
    try {
      body = JSON.parse(body || "{}");
    } catch {
      return jsonError(res, 400, "Invalid JSON request.");
    }
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return jsonError(res, 400, "Invalid booking request.");
  }

  // Honeypot: quietly accept bot submissions without recording them.
  if (String(body.website || "").trim()) {
    return res.status(200).json({ ok: true });
  }

  const name = String(body.name || "").trim();
  const service = String(body.service || "").trim();
  const date = String(body.date || "").trim();
  const time = String(body.time || "").trim();
  const phone = String(body.phone || "").trim();
  const notes = String(body.notes || "").trim();
  const phoneDigits = phone.replace(/\D/g, "");

  if (name.length < 2 || name.length > 80) return jsonError(res, 400, "Please enter a valid name.");
  if (!service || service.length > 100) return jsonError(res, 400, "Please choose a valid service.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return jsonError(res, 400, "Please enter a valid event date.");
  if (!/^\d{2}:\d{2}$/.test(time)) return jsonError(res, 400, "Please enter a valid event time.");
  if (phoneDigits.length < 8 || phoneDigits.length > 15) return jsonError(res, 400, "Please enter a valid phone number.");
  if (notes.length > 1000) return jsonError(res, 400, "Additional details are too long.");

  const insertUrl = `${supabaseUrl.replace(/\/$/, "")}/rest/v1/bookings`;
  try {
    const result = await fetch(insertUrl, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json",
        Prefer: "return=minimal"
      },
      body: JSON.stringify({
        full_name: name,
        service,
        event_date: date,
        event_time: time,
        phone,
        notes: notes || null,
        status: "new"
      })
    });

    if (!result.ok) {
      const errorText = await result.text();
      console.error("Supabase insert failed:", result.status, errorText);
      return jsonError(res, 502, "The booking database could not save this request.");
    }

    return res.status(201).json({ ok: true });
  } catch (error) {
    console.error("Booking function error:", error);
    return jsonError(res, 500, "Unexpected server error while saving the booking.");
  }
}
