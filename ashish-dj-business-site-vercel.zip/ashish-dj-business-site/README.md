# Ashish DJ Music — Business Website

A responsive four-page website for Ashish DJ Music, Rewa, Madhya Pradesh. It includes an animated landing page, services, about, contact/booking form, WhatsApp message generation, and an optional secure booking database integration.

## 1. Project files

```text
ashish-dj-business-site/
├── index.html
├── services.html
├── about.html
├── booking.html
├── assets/
│   ├── css/styles.css
│   ├── js/config.js
│   ├── js/main.js
│   └── images/favicon.svg
├── api/bookings.js                 # Vercel serverless booking endpoint
├── netlify/functions/bookings.mjs  # Netlify alternative
├── supabase-setup.sql
├── vercel.json
├── netlify.toml
└── README.md
```

## 2. Before publishing: add your WhatsApp Business number

1. Open `assets/js/config.js` in a code editor.
2. Find `whatsappNumber: "91XXXXXXXXXX"`.
3. Replace it with your WhatsApp Business number, including country code, digits only. Example format for India: `919876543210` (this is only an example; use your own number).
4. Save the file.

Do not add `+`, spaces, hyphens or brackets to this value. The website checks the number and will show a setup message until a real number is entered.

Your Instagram and YouTube links are already set to the Ashish DJ Music profiles known for this project. Update them in `config.js` if needed; the footer links in the HTML pages can also be changed.

## 3. Test the static website

You can open `index.html` in a browser to inspect the pages. For a more realistic local test, serve the folder using VS Code's Live Server extension or run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`. WhatsApp booking works after you add your number. The database function needs Vercel or Netlify hosting and Supabase credentials.

## 4. WhatsApp booking flow

The booking form checks required fields and phone format, creates a pre-filled message containing name, service, date, time, phone and optional notes, then opens `https://wa.me/` in a new tab. The visitor still has to press **Send** in WhatsApp; a website cannot send a WhatsApp message silently.

At the same time, the form posts the booking details to `/api/bookings` (Vercel). If the database is not configured, WhatsApp still opens and the page clearly tells the visitor that database saving is unavailable.

## 5. Recommended database: Supabase (PostgreSQL)

For this booking use case, Supabase is a strong fit because event bookings are structured records (name, service, date, time, phone, notes, status), and PostgreSQL makes sorting, filtering and reporting straightforward. Supabase provides a hosted Postgres database and a dashboard where you can view and manage rows.

### Create the database

1. Create a free Supabase project at <https://supabase.com/>.
2. Open **SQL Editor** in the Supabase dashboard.
3. Choose **New query**.
4. Copy the full contents of `supabase-setup.sql` into the editor and run it.
5. Open **Project Settings → API** (or API Keys, depending on the dashboard version). Copy the project URL and the server-side `service_role` key. Never put this key in `assets/js/config.js`, HTML, or any browser code.

### Connect Supabase to Vercel

After the website has been imported into Vercel:

1. Open the Vercel project dashboard.
2. Go to **Settings → Environment Variables**.
3. Add `SUPABASE_URL` with your Supabase project URL.
4. Add `SUPABASE_SERVICE_ROLE_KEY` with the server-side service-role key.
5. Select the environments where the values should apply (at least Production), save, and redeploy.

Do not add the service-role key to a `NEXT_PUBLIC_` variable or browser file. The included Vercel Function validates and inserts the booking using the secret key on the server. Public browser roles have no direct table access. To review enquiries later, open Supabase → **Table Editor → bookings**. Change a booking's `status` to `confirmed`, `completed`, or `cancelled` as needed.

**Security:** Do not commit secret keys to GitHub. Do not disable Row Level Security or grant public access to the bookings table. This starter has basic validation and a honeypot field; for a high-traffic production site, add CAPTCHA/bot protection and server-side rate limiting.

## 6. Free hosting: deploy with Vercel (recommended for this prepared package)

Vercel can host the four static pages and the included `api/bookings.js` serverless function in the same project. Check Vercel pricing and current usage limits before launch.

### A. Create a GitHub repository

1. Sign in to <https://github.com/> or create a free account.
2. Click **New repository**. Name it `ashish-dj-music-website` and choose **Private** for privacy, or Public if you prefer to make the source visible.
3. Upload the contents of this project folder to the repository root. Important: upload the files and folders inside `ashish-dj-business-site`, not a second nested folder containing the project.
4. Confirm that `index.html`, `netlify.toml`, `assets/`, and `netlify/functions/` are visible at the top level of the repository.

### B. Import the repository into Vercel

1. Sign in at <https://vercel.com/>.
2. Select **Add New → Project** and connect your GitHub account.
3. Import `ashish-dj-music-website`.
4. Keep the project root at the repository root. No build command is required for this plain HTML/CSS/JavaScript project.
5. Deploy. Vercel serves the HTML pages and discovers the function in `api/bookings.js`.
6. Open the generated `https://your-project.vercel.app` link.

### C. Add the database environment variables

Follow section 5 to add `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in Vercel. Redeploy after adding them. Then test one booking with a real future date and check that it appears in Supabase → Table Editor → `bookings`.

### D. Final launch checklist

- [ ] Replace `91XXXXXXXXXX` in `assets/js/config.js` with your actual WhatsApp Business number.
- [ ] Confirm your Instagram and YouTube links.
- [ ] Check all four pages on a phone and a desktop.
- [ ] Submit a test booking and confirm the WhatsApp message text.
- [ ] If using Supabase, verify that the test row appears in the `bookings` table.
- [ ] Remove test bookings from the dashboard before sharing the public link.

## 7. Other hosting choices

- **Netlify:** the original `netlify/functions/bookings.mjs` and `netlify.toml` are retained, so the same source can also be deployed there using GitHub import. Use the Netlify Function URL only if you switch the frontend endpoint in `assets/js/main.js` back to `/.netlify/functions/bookings`.
- **GitHub Pages:** suitable for static files only; it will not run the database function. WhatsApp can still work after adding the real number.
- **Surge:** suitable for basic static hosting only; it will not run the database function.

For the full WhatsApp + database setup, use Vercel + Supabase with this prepared Vercel endpoint.

## 8. Important booking note

The WhatsApp pre-filled text is generated by the website, but customers must press **Send** in WhatsApp themselves. The database request is stored separately, so the customer may appear in the database even if they close WhatsApp without sending. Follow up using the phone number recorded in Supabase.
