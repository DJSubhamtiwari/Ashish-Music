/*
 * EDIT THIS FILE BEFORE PUBLISHING.
 * WhatsApp number must include the country code, digits only.
 * India example: 91 followed by your 10-digit mobile number.
 */
window.SITE_CONFIG = {
  brandName: "Ashish DJ Music",
  whatsappNumber: "91XXXXXXXXXX", // IMPORTANT: replace Xs with your WhatsApp Business number
  instagramUrl: "https://www.instagram.com/ashish_dj_light_/",
  youtubeUrl: "https://www.youtube.com/@AshishDJMusic01",
  location: "Rewa, Madhya Pradesh, India"
};
