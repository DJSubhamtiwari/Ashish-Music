(() => {
  "use strict";

  const config = window.SITE_CONFIG || {};
  const $ = (selector, root = document) => root.querySelector(selector);

  // Mobile navigation
  const navToggle = $(".nav-toggle");
  const siteNav = $(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isOpen));
      navToggle.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
      siteNav.classList.toggle("is-open", !isOpen);
      document.body.classList.toggle("nav-open", !isOpen);
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.setAttribute("aria-label", "Open navigation");
        siteNav.classList.remove("is-open");
        document.body.classList.remove("nav-open");
      });
    });
  }

  // Dynamic copyright year
  const year = $("[data-year]");
  if (year) year.textContent = String(new Date().getFullYear());

  // Reveal-on-scroll animation. Content remains visible if IntersectionObserver is unavailable.
  const revealItems = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries, activeObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          activeObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach((item) => observer.observe(item));
  } else {
    revealItems.forEach((item) => item.classList.add("is-visible"));
  }

  // Booking form: validate, open WhatsApp synchronously, then save to the optional Netlify/Supabase backend.
  const bookingForm = $("#bookingForm");
  if (!bookingForm) return;

  const status = $("#formStatus");
  const dateInput = $("#eventDate");
  const serviceSelect = $("#service");
  const params = new URLSearchParams(window.location.search);
  const requestedService = params.get("service");
  if (requestedService && serviceSelect) {
    const matchingOption = Array.from(serviceSelect.options).find((option) =>
      option.value.toLowerCase() === requestedService.toLowerCase() ||
      option.textContent.toLowerCase() === requestedService.toLowerCase()
    );
    if (matchingOption) serviceSelect.value = matchingOption.value;
  }

  // Prevent choosing a date in the past, using the visitor's local calendar date.
  if (dateInput) {
    const now = new Date();
    const localToday = [now.getFullYear(), String(now.getMonth() + 1).padStart(2, "0"), String(now.getDate()).padStart(2, "0")].join("-");
    dateInput.min = localToday;
  }

  const setStatus = (message, type = "info") => {
    if (!status) return;
    status.textContent = message;
    status.className = `form-status ${type}`;
  };

  const isValidBusinessNumber = (value) => /^\d{10,15}$/.test(String(value || ""));

  bookingForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    setStatus("");

    // Native required/type checks plus a little extra phone-number validation.
    if (!bookingForm.checkValidity()) {
      bookingForm.reportValidity();
      return;
    }

    const formData = new FormData(bookingForm);
    const booking = {
      name: String(formData.get("name") || "").trim(),
      service: String(formData.get("service") || "").trim(),
      date: String(formData.get("date") || ""),
      time: String(formData.get("time") || ""),
      phone: String(formData.get("phone") || "").trim(),
      notes: String(formData.get("notes") || "").trim(),
      website: String(formData.get("website") || "").trim()
    };

    const phoneDigits = booking.phone.replace(/\D/g, "");
    if (phoneDigits.length < 8 || phoneDigits.length > 15) {
      setStatus("Please enter a valid phone number, including country code if needed.", "error");
      $("#phone").focus();
      return;
    }

    // Honeypot anti-spam field: do not process submissions filled by simple bots.
    if (booking.website) {
      setStatus("Thank you. Your request has been received.", "success");
      bookingForm.reset();
      return;
    }

    if (!isValidBusinessNumber(config.whatsappNumber)) {
      setStatus("Setup needed: add your WhatsApp Business number in assets/js/config.js (country code + number, digits only), then try again.", "error");
      return;
    }

    const message = [
      `Hello ${config.brandName || "Ashish DJ Music"}! I want to enquire about a booking.`,
      "",
      `Name: ${booking.name}`,
      `Service / Event: ${booking.service}`,
      `Event Date: ${booking.date}`,
      `Event Time: ${booking.time}`,
      `My Phone: ${booking.phone}`,
      booking.notes ? `Additional Details: ${booking.notes}` : "",
      "",
      "Please share availability and package details. Thank you!"
    ].filter(Boolean).join("\n");

    const whatsappUrl = `https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`;
    // Open a blank tab during the original click. If popups are blocked, redirect this tab
    // only after the database request settles so the save is not interrupted by navigation.
    let whatsappWindow = null;
    try {
      whatsappWindow = window.open("about:blank", "_blank");
      if (whatsappWindow) {
        whatsappWindow.opener = null;
        whatsappWindow.location.href = whatsappUrl;
      }
    } catch (error) {
      console.warn("Could not open a WhatsApp tab:", error);
      whatsappWindow = null;
    }

    setStatus("WhatsApp is opening. Saving your booking request…", "info");

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(booking)
      });

      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.error || `Server returned ${response.status}`);
      }

      setStatus("WhatsApp opened and your booking request was saved. Please press Send in WhatsApp to complete the enquiry.", "success");
      bookingForm.reset();
      if (dateInput) {
        const today = new Date();
        dateInput.min = [today.getFullYear(), String(today.getMonth() + 1).padStart(2, "0"), String(today.getDate()).padStart(2, "0")].join("-");
      }
    } catch (error) {
      console.warn("Booking database save was not available:", error);
      setStatus("WhatsApp opened. The database could not save this request yet. Please press Send in WhatsApp; database saving works after Vercel and Supabase are configured.", "warning");
    }

    // Fallback for browsers that blocked the new tab.
    if (!whatsappWindow) window.location.href = whatsappUrl;
  });
})();
