-- Run this once in Supabase Dashboard > SQL Editor > New query.
-- Booking data is intentionally not readable/writable by public browser roles.
-- The Netlify serverless function inserts rows using a server-side service-role key.

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (char_length(full_name) between 2 and 80),
  service text not null check (char_length(service) between 1 and 100),
  event_date date not null,
  event_time time not null,
  phone text not null,
  notes text,
  status text not null default 'new' check (status in ('new', 'confirmed', 'completed', 'cancelled')),
  created_at timestamptz not null default now()
);

create index if not exists bookings_created_at_idx on public.bookings (created_at desc);
create index if not exists bookings_event_date_idx on public.bookings (event_date);

alter table public.bookings enable row level security;

-- Remove direct API permissions from public browser roles.
revoke all on table public.bookings from anon, authenticated;
-- The server-side service role is privileged and bypasses RLS. Keep its key secret.
grant all on table public.bookings to service_role;
