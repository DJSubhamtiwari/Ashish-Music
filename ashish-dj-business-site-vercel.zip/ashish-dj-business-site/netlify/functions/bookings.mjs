/**
 * Netlify serverless function: validates a booking enquiry and inserts it into Supabase.
 * SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be configured in Netlify's environment.
 * Never move the service-role key into browser-side JavaScript.
 */
const json = (statusCode, payload) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(payload)
});

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Method not allowed" });
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceKey) {
    return json(503, { error: "Booking database is not configured yet." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Invalid JSON request." });
  }

  // Honeypot: quietly accept bot submissions without recording them.
  if (String(body.website || "").trim()) {
    return json(200, { ok: true });
  }

  const name = String(body.name || "").trim();
  const service = String(body.service || "").trim();
  const date = String(body.date || "").trim();
  const time = String(body.time || "").trim();
  const phone = String(body.phone || "").trim();
  const notes = String(body.notes || "").trim();
  const phoneDigits = phone.replace(/\D/g, "");

  if (name.length < 2 || name.length > 80) return json(400, { error: "Please enter a valid name." });
  if (!service || service.length > 100) return json(400, { error: "Please choose a valid service." });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return json(400, { error: "Please enter a valid event date." });
  if (!/^\d{2}:\d{2}$/.test(time)) return json(400, { error: "Please enter a valid event time." });
  if (phoneDigits.length < 8 || phoneDigits.length > 15) return json(400, { error: "Please enter a valid phone number." });
  if (notes.length > 1000) return json(400, { error: "Additional details are too long." });

  const insertUrl = `${supabaseUrl.replace(/\/$/, "")}/rest/v1/bookings`;
  try {
    const result = await fetch(insertUrl, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json",
        Prefer: "return=minimal"
      },
      body: JSON.stringify({
        full_name: name,
        service,
        event_date: date,
        event_time: time,
        phone,
        notes: notes || null,
        status: "new"
      })
    });

    if (!result.ok) {
      const errorText = await result.text();
      console.error("Supabase insert failed:", result.status, errorText);
      return json(502, { error: "The booking database could not save this request." });
    }

    return json(201, { ok: true });
  } catch (error) {
    console.error("Booking function error:", error);
    return json(500, { error: "Unexpected server error while saving the booking." });
  }
};
